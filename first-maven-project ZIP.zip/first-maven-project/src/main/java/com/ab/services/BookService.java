package com.ab.services;

import java.util.List;

import com.ab.daos.BookDAO;
import com.ab.models.Book;

public class BookService {
	
	
	
	private BookDAO bookDAO;
	
	
	
	public BookService(BookDAO bookDAO) {
		
		this.bookDAO = bookDAO;
	}
	
	
	
	public List<Book> viewAllBooks(){
		
		return this.bookDAO.viewAllBooks();
	}
	
	
	
	public List<Book> searchBook(String title) {
		
		return this.bookDAO.searchBook(title);
		
	}
	
	public List<Book> listBookInfo(String title){
		
		return this.bookDAO.listBookInfo(title);
	}
	
	public Book getBook(String title) {
		
		return this.bookDAO.getBook(title);
	}

}
