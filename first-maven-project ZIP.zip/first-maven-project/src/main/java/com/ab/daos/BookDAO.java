package com.ab.daos;

import java.util.List;

import com.ab.models.Book;

public interface BookDAO {

	public List<Book> viewAllBooks();
	
	public List<Book> searchBook(String title);
	
	public List<Book> listBookInfo(String title);
	
	public Book getBook(String title);
	
}
