package com.ab.daos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ab.models.Book;

public class BookDAOImpl implements BookDAO{
	
	private Connection con;
	
	private PreparedStatement pst;
	
	private ResultSet rs;
	
	public BookDAOImpl() {
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			this.con = DriverManager.getConnection("jdbc:mysql://localhost/test","root",""); 
			
			
		}
		catch(ClassNotFoundException e) {
			
			System.out.println(e);
		}
		catch(SQLException e) {
			
			
			System.out.println(e);
		}

		
	}
	
	
	
	

	@Override
	public List<Book> viewAllBooks() {
		
		List<Book> books = new ArrayList<>();
		
		try {
			
			this.pst = this.con.prepareStatement("SELECT * from book");
			this.rs = this.pst.executeQuery();
			
			// convert result set into objects
			while(this.rs.next()) {
				
				Book b = new Book(this.rs.getInt("book_id"),
						this.rs.getString("book_name"),
						this.rs.getString("author"),
						this.rs.getString("overview"),
						this.rs.getInt("price")
						);
				books.add(b);
				
			}
			
			
		}
		catch(SQLException e) {
			
			System.out.println("SQL Exception in BookDAOImpl class");
			System.out.println(e);
			return null;
		}
		
		return books;
	}





	@Override
	public List<Book> searchBook(String title) {
			// to -do : implement the search book
		
		
		List<Book> books = new ArrayList<>();
		
		try {
			 
				this.pst = this.con.prepareStatement("SELECT * FROM book "
						+ "WHERE book_name LIKE ? ");
				
				// if there is only 1 parameter to set do you write the  number 1
				this.pst.setString(1, "%" + title + "%");
				this.rs = this.pst.executeQuery();
				
				while(this.rs.next()) {
					
					Book b = new Book(this.rs.getInt("book_id"),
							this.rs.getString("book_name"),
							this.rs.getString("author"),
							this.rs.getString("overview"),
							this.rs.getInt("price")
							);
					
					books.add(b);	
					
				}
				
				//return books;
			
			}
		catch(SQLException e){
			
			System.out.println(e);
			return null;
		}
		
		return books;
	}





	@Override
	public List<Book> listBookInfo(String title) {
		
		List<Book> books = new ArrayList<>();
		
		try {
			 
				this.pst = this.con.prepareStatement("SELECT * FROM book "
						+ "WHERE book_name LIKE ? ");
				
				// if there is only 1 parameter to set do you write the  number 1
				this.pst.setString(1, "%" + title + "%");
				this.rs = this.pst.executeQuery();
				
				while(this.rs.next()) {
					
					Book b = new Book(this.rs.getInt("book_id"),
							this.rs.getString("book_name"),
							this.rs.getString("author"),
							this.rs.getString("overview"),
							this.rs.getInt("price")
							);
					
					books.add(b);	
					
				}
				
				//return books;
			
			}
		catch(SQLException e){
			
			System.out.println(e);
			return null;
		}
		
		return books;
	}





	@Override
	public Book getBook(String title) {
		
		try {
			
			this.pst = this.con.prepareStatement("SELECT * FROM book  WHERE book_name = ?");
			this.pst.setString(1, title);
			
			this.rs = this.pst.executeQuery();
			if(this.rs.next()) {
				
				Book b = new Book(this.rs.getInt("book_id"),
						this.rs.getString("book_name"),
						this.rs.getString("author"),
						this.rs.getString("overview"),
						this.rs.getInt("price")
						);
				return b;
				
					}
		}
		catch(SQLException e) {
			
			System.out.println(e);
			return null;
		}
		
		return null;
	}

	
	
}
