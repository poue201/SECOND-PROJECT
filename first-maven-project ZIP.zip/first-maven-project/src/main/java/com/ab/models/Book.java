package com.ab.models;

public class Book {

	private int bookId;
	private String bookName;
	private String bookAuthor;
	private String overview;
	private int price;
	private int quantity = 1;
	
	public Book() {}
	
	

	public int getQuantity() {
		return quantity;
	}



	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}



	public Book(int bookId, String bookName, String bookAuthor, String overview, int price, int quantity) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.bookAuthor = bookAuthor;
		this.overview = overview;
		this.price = price;
		this.quantity = quantity;
	}



	public Book(int bookId, String bookName, String bookAuthor, String overview, int price) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.bookAuthor = bookAuthor;
		this.overview = overview;
		this.price = price;
	}



	public Book(int bookId, String bookName, String bookAuthor, String overview) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.bookAuthor = bookAuthor;
		this.overview = overview;
	}

	public Book(String bookName, String bookAuthor, String overview) {
		super();
		this.bookName = bookName;
		this.bookAuthor = bookAuthor;
		this.overview = overview;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getBookAuthor() {
		return bookAuthor;
	}

	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}

	public String getOverview() {
		return overview;
	}

	public void setOverview(String overview) {
		this.overview = overview;
	}
	
	

	public int getPrice() {
		return this.price;
	}



	public void setPrice(int price) {
		this.price = price;
	}



	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookName=" + bookName + ", bookAuthor=" + bookAuthor + ", overview="
				+ overview + "]";
	};
	
	
}
