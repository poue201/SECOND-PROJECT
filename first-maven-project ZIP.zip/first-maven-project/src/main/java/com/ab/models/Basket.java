package com.ab.models;

import java.util.ArrayList;
import java.util.List;

public class Basket {
	
	private List<Book> listOfBooks = new ArrayList<Book>();
	
	private double totalPrice;
	
	public Basket() {}
	
	
	
	public Basket(List<Book> listOfBooks, double totalPrice) {
		super();
		this.listOfBooks = listOfBooks;
		this.totalPrice = totalPrice;
		//for(Book b : this.listOfBooks) {
			
			//this.totalPrice += b.getQuantity() * b.getPrice();
		//}
		
	}


	public void addToBasket(Book book) {
		this.listOfBooks.add(book);
	}



	public List<Book> getListOfBooks() {
		return listOfBooks;
	}



	public void setListOfBooks(List<Book> listOfBooks) {
		this.listOfBooks = listOfBooks;
	}



	public double getTotalPrice() {
		return totalPrice;
	}



	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}



	@Override
	public String toString() {
		return "Basket [listOfBooks=" + listOfBooks + ", totalPrice=" + totalPrice + "]";
	}
	
	
//	public int calculateTotal() {
//		
//		int total = 0;
//		for(Book b : this.listOfBooks) {
//			
//			total = getTotalPrice() +  b.getQuantity() * b.getPrice();
//		}
//		return total;
//	}

	
	
	
	

}
