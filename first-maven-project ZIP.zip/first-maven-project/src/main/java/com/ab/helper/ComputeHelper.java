package com.ab.helper;

import java.util.List;

import com.ab.models.Basket;
import com.ab.models.Book;

public class ComputeHelper {
	
	
	
	public static int CalculateTotal(Basket b) {
		
		int total = 0;
		for(Book book : b.getListOfBooks()) {
			
			total += book.getQuantity() * book.getPrice();
		}
		
		return total;
	}
	
public static int CalculateTotalList(List<Book> bookList) {
		
		int total = 0;
		for(Book book : bookList) {
			
			total += book.getQuantity() * book.getPrice();
		}
		
		return total;
	}


}
