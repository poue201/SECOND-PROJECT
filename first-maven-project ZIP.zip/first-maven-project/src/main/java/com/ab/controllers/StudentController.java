package com.ab.controllers;

import java.util.List;

import com.ab.models.Student;
import com.ab.services.StudentService;

public class StudentController {
	
	private StudentService studentService;
	
	public StudentController(StudentService studentService) {
		
		this.studentService = studentService;
		
	}
	
	// Mapping methods
	
	public int registerStudent(Student s) {
		
		return this.studentService.registerStudent(s);
	}
	
	public Student loginStudent(String username, String password) {
		
		return this.studentService.studentLogin(username, password);
	}
	
	
	public List<Student> getAllStudents(){
		return this.studentService.findAllStudents();
		
	}

}
