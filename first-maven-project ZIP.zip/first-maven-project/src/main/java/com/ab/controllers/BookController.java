package com.ab.controllers;

import java.util.List;

import com.ab.models.Book;
import com.ab.services.BookService;

public class BookController {
	
	
	private BookService bookService;
	
	
	
	
	public BookController(BookService bookService) {
		
		this.bookService = bookService;
	}
	
	
	
	
	public List<Book> viewAllBooks(){
		
		return this.bookService.viewAllBooks();
	}
	
	
	
	public  List<Book> searchBook(String title) {
		
		return this.bookService.searchBook(title);
	}
	
	public List<Book> listBookInfo(String title){
		
		return this.bookService.listBookInfo(title);
	}
	
	public Book getBook(String title) {
		
		return this.bookService.getBook(title);
	}

}
